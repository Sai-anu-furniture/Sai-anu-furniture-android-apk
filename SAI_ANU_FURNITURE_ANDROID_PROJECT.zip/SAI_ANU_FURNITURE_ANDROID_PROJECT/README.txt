SAI ANU FURNITURE - ANDROID STUDIO PROJECT

This ZIP is an Android Studio project source package, NOT a compiled APK.

HOW TO BUILD THE APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted SAI_ANU_FURNITURE_ANDROID_PROJECT folder.
4. Wait for Gradle sync to finish. If prompted, install Android SDK Platform 35 and accept the license.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show a link to the generated APK. The usual output path is:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer that APK to your Android phone and install it. You may need to allow installation from that file manager.

APP DETAILS
- Business: SAI ANU FURNITURE
- Phone / WhatsApp: +91 91773 04055
- Location: IDA Patancheru, Telangana
- Includes sofa catalogue, custom enquiry, sofa repair booking, local demo admin view.
- Customer requests are stored only in this device/app browser storage for this prototype.
- No cloud database, secure admin login, notifications, online payments, or multi-device syncing is connected yet.
- The Admin screen is a demo and is NOT password protected.

To publish on Google Play, the app needs further testing, a signed release build, a privacy policy, and Play Console setup.
