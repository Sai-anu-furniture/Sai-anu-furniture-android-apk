import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";
const OWNER_UID = "REPLACE_WITH_OWNER_UID";
const auth = getAuth(initializeApp(firebaseConfig));
onAuthStateChanged(auth, async user => {
 if (!user || user.uid !== OWNER_UID) { await signOut(auth); location.replace("admin-login.html"); return; }
 document.getElementById("who").textContent = "Signed in as " + user.email;
});
document.getElementById("logout").addEventListener("click", () => signOut(auth).then(() => location.replace("admin-login.html")));
