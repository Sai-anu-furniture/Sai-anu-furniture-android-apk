import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";

const OWNER_UID = "REPLACE_WITH_OWNER_UID"; // Must match the UID in both Firebase security rules.
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const msg = document.getElementById("msg");
const form = document.getElementById("loginForm");

form?.addEventListener("submit", async (event) => {
  event.preventDefault(); msg.textContent = "Signing in…";
  try {
    const cred = await signInWithEmailAndPassword(auth, document.getElementById("email").value.trim(), document.getElementById("password").value);
    if (cred.user.uid !== OWNER_UID) { await signOut(auth); throw new Error("This account is not authorised for the owner dashboard."); }
    location.href = "admin-dashboard.html";
  } catch (e) { msg.textContent = e.message || "Login failed."; }
});

onAuthStateChanged(auth, async (user) => {
  if (user && user.uid !== OWNER_UID) { await signOut(auth); msg.textContent = "Access denied."; }
});
